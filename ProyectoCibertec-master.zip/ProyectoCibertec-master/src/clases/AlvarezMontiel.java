package clases;

public class AlvarezMontiel {
	// ALVARO PAVO
//yara causa
	private int codigo, precio;
	private String TEXTO, nombre;
	private double impc, impd, impb, impt;
	
	
	private AlvarezMontiel(int codigo, int precio,String TEXTO, String nombre,double impc, double impd, double impb, double impt) {
		this.codigo=codigo;
		this.impb=impb;
		this.impc=impc;
		this.impd=impd;
		this.impt=impt;
		this.nombre=nombre;
		this.TEXTO=TEXTO;
	}
	
	private AlvarezMontiel() {}

}
