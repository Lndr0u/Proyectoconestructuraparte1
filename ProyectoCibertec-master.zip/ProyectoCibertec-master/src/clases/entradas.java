package clases;

public class entradas {

}
