/**
 * 
 */
/**
 * 
 */
module ProyectoCineCibertec {
	requires java.desktop;
}